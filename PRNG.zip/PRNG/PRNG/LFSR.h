#pragma once
#include "iostream"
#include "vector"
#include "fstream"
#include "string"
#include "LFSR113.h"
#include "LFSRInfo.h"
namespace PRNG {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� LFSR
	/// </summary>
	public ref class LFSR : public System::Windows::Forms::Form
	{
	public:
		LFSR(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~LFSR()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::TextBox^ textBox3;
	private: System::Windows::Forms::TextBox^ textBox4;
	private: System::Windows::Forms::TextBox^ textBox5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::TextBox^ textBox6;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^ chart1;
	private: System::Windows::Forms::Button^ button4;
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ ����������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ ���������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ �����������������ToolStripMenuItem;

	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Series^ series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->chart1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->����������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->���������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�����������������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->BeginInit();
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label1->Location = System::Drawing::Point(12, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(231, 29);
			this->label1->TabIndex = 0;
			this->label1->Text = L"��������� ������:";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label2->Location = System::Drawing::Point(12, 74);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(39, 29);
			this->label2->TabIndex = 1;
			this->label2->Text = L"u1";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label3->Location = System::Drawing::Point(12, 112);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(39, 29);
			this->label3->TabIndex = 2;
			this->label3->Text = L"u2";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label4->Location = System::Drawing::Point(12, 150);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(39, 29);
			this->label4->TabIndex = 3;
			this->label4->Text = L"u3";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label5->Location = System::Drawing::Point(12, 188);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(39, 29);
			this->label5->TabIndex = 4;
			this->label5->Text = L"u4";
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox1->Location = System::Drawing::Point(57, 71);
			this->textBox1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(185, 34);
			this->textBox1->TabIndex = 5;
			this->textBox1->Text = L"123";
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox2->Location = System::Drawing::Point(57, 109);
			this->textBox2->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(185, 34);
			this->textBox2->TabIndex = 6;
			this->textBox2->Text = L"123";
			// 
			// textBox3
			// 
			this->textBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox3->Location = System::Drawing::Point(57, 147);
			this->textBox3->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(185, 34);
			this->textBox3->TabIndex = 7;
			this->textBox3->Text = L"123";
			// 
			// textBox4
			// 
			this->textBox4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox4->Location = System::Drawing::Point(57, 185);
			this->textBox4->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(185, 34);
			this->textBox4->TabIndex = 8;
			this->textBox4->Text = L"213";
			// 
			// textBox5
			// 
			this->textBox5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox5->Location = System::Drawing::Point(17, 326);
			this->textBox5->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(336, 34);
			this->textBox5->TabIndex = 9;
			this->textBox5->Text = L"100";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label6->Location = System::Drawing::Point(12, 294);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(452, 29);
			this->label6->TabIndex = 10;
			this->label6->Text = L"�������� ����� ������������������";
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button1->Location = System::Drawing::Point(17, 394);
			this->button1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(253, 66);
			this->button1->TabIndex = 11;
			this->button1->Text = L"�������������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &LFSR::button1_Click);
			// 
			// button2
			// 
			this->button2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button2->Location = System::Drawing::Point(17, 534);
			this->button2->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(253, 66);
			this->button2->TabIndex = 12;
			this->button2->Text = L"�������� ����";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &LFSR::button2_Click);
			// 
			// button3
			// 
			this->button3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button3->Location = System::Drawing::Point(17, 604);
			this->button3->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(253, 66);
			this->button3->TabIndex = 13;
			this->button3->Text = L"�����";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &LFSR::button3_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->label7->Location = System::Drawing::Point(643, 28);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(525, 29);
			this->label7->TabIndex = 14;
			this->label7->Text = L"������������������ ��������������� �����";
			// 
			// textBox6
			// 
			this->textBox6->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->textBox6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->textBox6->Location = System::Drawing::Point(470, 61);
			this->textBox6->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->textBox6->Multiline = true;
			this->textBox6->Name = L"textBox6";
			this->textBox6->ScrollBars = System::Windows::Forms::ScrollBars::Both;
			this->textBox6->Size = System::Drawing::Size(782, 609);
			this->textBox6->TabIndex = 15;
			// 
			// chart1
			// 
			this->chart1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			chartArea1->AxisX->IsLabelAutoFit = false;
			chartArea1->AxisX->LabelStyle->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			chartArea1->AxisX->Title = L"i";
			chartArea1->AxisX->TitleFont = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			chartArea1->AxisY->IsLabelAutoFit = false;
			chartArea1->AxisY->LabelStyle->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			chartArea1->AxisY->Title = L"Z_i";
			chartArea1->AxisY->TitleFont = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(204)));
			chartArea1->Name = L"ChartArea1";
			this->chart1->ChartAreas->Add(chartArea1);
			this->chart1->Location = System::Drawing::Point(470, 61);
			this->chart1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->chart1->Name = L"chart1";
			series1->ChartArea = L"ChartArea1";
			series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Point;
			series1->Color = System::Drawing::Color::Red;
			series1->Name = L"Series1";
			this->chart1->Series->Add(series1);
			this->chart1->Size = System::Drawing::Size(782, 609);
			this->chart1->TabIndex = 16;
			this->chart1->Text = L"chart1";
			// 
			// button4
			// 
			this->button4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->button4->Location = System::Drawing::Point(17, 464);
			this->button4->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(253, 66);
			this->button4->TabIndex = 17;
			this->button4->Text = L"��������� ������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &LFSR::button4_Click);
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {
				this->����������ToolStripMenuItem,
					this->���������ToolStripMenuItem, this->�����������������ToolStripMenuItem
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Padding = System::Windows::Forms::Padding(5, 2, 0, 2);
			this->menuStrip1->Size = System::Drawing::Size(1264, 28);
			this->menuStrip1->TabIndex = 18;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// ����������ToolStripMenuItem
			// 
			this->����������ToolStripMenuItem->Name = L"����������ToolStripMenuItem";
			this->����������ToolStripMenuItem->Size = System::Drawing::Size(118, 24);
			this->����������ToolStripMenuItem->Text = L"� ���������";
			this->����������ToolStripMenuItem->Click += gcnew System::EventHandler(this, &LFSR::����������ToolStripMenuItem_Click);
			// 
			// ���������ToolStripMenuItem
			// 
			this->���������ToolStripMenuItem->Name = L"���������ToolStripMenuItem";
			this->���������ToolStripMenuItem->Size = System::Drawing::Size(97, 24);
			this->���������ToolStripMenuItem->Text = L"���������";
			this->���������ToolStripMenuItem->Click += gcnew System::EventHandler(this, &LFSR::���������ToolStripMenuItem_Click);
			// 
			// �����������������ToolStripMenuItem
			// 
			this->�����������������ToolStripMenuItem->Name = L"�����������������ToolStripMenuItem";
			this->�����������������ToolStripMenuItem->Size = System::Drawing::Size(173, 24);
			this->�����������������ToolStripMenuItem->Text = L"������� ����������";
			this->�����������������ToolStripMenuItem->Click += gcnew System::EventHandler(this, &LFSR::�����������������ToolStripMenuItem_Click);
			// 
			// LFSR
			// 
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Inherit;
			this->ClientSize = System::Drawing::Size(1264, 681);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->chart1);
			this->Controls->Add(this->textBox6);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->textBox5);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->Name = L"LFSR";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"LFSR";
			this->Load += gcnew System::EventHandler(this, &LFSR::LFSR_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart1))->EndInit();
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		chart1->Hide();
		unsigned long long u1, u2, u3, u4, el;
		int len;
		if (textBox1->Text == "" || textBox2->Text == "" || textBox3->Text == "" || textBox4->Text == "" || textBox5->Text == "") MessageBox::Show("���� �����!");
		else
		{
			u1 = Convert::ToInt32(textBox1->Text);
			u2 = Convert::ToInt32(textBox2->Text);
			u3 = Convert::ToInt32(textBox3->Text);
			u4 = Convert::ToInt32(textBox4->Text);
			len = Convert::ToInt32(textBox5->Text);
			std::vector<unsigned long long> seq;
			if (len <= 0)
				MessageBox::Show("����� ������� �� ����� ���� ������������� ��� ������ ����!");
			else if (Convert::ToInt32(textBox1->Text) <= 1 || Convert::ToInt32(textBox2->Text) <= 7 || Convert::ToInt32(textBox3->Text) <= 15 || Convert::ToInt32(textBox4->Text) <= 127)
			{
				MessageBox::Show("�������� ��� ��������� ��������� �������!");
				textBox1->Clear();
				textBox2->Clear();
				textBox3->Clear();
				textBox4->Clear();
				textBox5->Clear();
				textBox6->Clear();
			}
			else
			{
				textBox6->Text = "(";
				for (int i = 0; i < len; i++)
				{
					el = lfsr113_ansi_generate_(u1, u2, u3, u4);
					seq.push_back(el);
					textBox6->Text += Convert::ToString(el);
					if (i != len - 1)
						textBox6->Text += "; ";
				}
				textBox6->Text += ")";
			}
		}
	}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	textBox1->Clear();
	textBox2->Clear();
	textBox3->Clear();
	textBox4->Clear();
	textBox5->Clear();
	textBox6->Clear();
	this->chart1->Series[0]->Points->Clear();
	chart1->Hide();
}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}
private: System::Void button4_Click(System::Object^ sender, System::EventArgs^ e) {
	unsigned long long u1, u2, u3, u4, len, el;
	if (textBox1->Text == "" || textBox2->Text == "" || textBox3->Text == "" || textBox4->Text == "" || textBox5->Text == "") MessageBox::Show("���� �����!");
	else
	{
		u1 = Convert::ToInt32(textBox1->Text);
		u2 = Convert::ToInt32(textBox2->Text);
		u3 = Convert::ToInt32(textBox3->Text);
		u4 = Convert::ToInt32(textBox4->Text);
		len = Convert::ToInt32(textBox5->Text);
		if (len < 0)
			MessageBox::Show("����� ������� �� ����� ���� ������������� ��� ������ ����!");
		else if (Convert::ToInt32(textBox1->Text) <= 1 || Convert::ToInt32(textBox2->Text) <= 7 || Convert::ToInt32(textBox3->Text) <= 15 || Convert::ToInt32(textBox4->Text) <= 127)
		{
			MessageBox::Show("�������� ��� ��������� ��������� �������!");
			textBox1->Clear();
			textBox2->Clear();
			textBox3->Clear();
			textBox4->Clear();
			textBox5->Clear();
			textBox6->Clear();
		}
		else {
			chart1->Show();
			this->chart1->Series[0]->Points->Clear();
			for (int i = 0; i < len; i++)
			{
				el = lfsr113_ansi_generate_(u1, u2, u3, u4);
				this->chart1->Series[0]->Points->AddXY(i + 1, el);
			}
		}
	}
}
private: System::Void LFSR_Load(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void ����������ToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	LFSRInfo^ new_form = gcnew LFSRInfo();
	new_form->Show();
}
private: System::Void ���������ToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	unsigned long long u1, u2, u3, u4, el;
	int len;
	if (textBox1->Text == "" || textBox2->Text == "" || textBox3->Text == "" || textBox4->Text == "" || textBox5->Text == "") MessageBox::Show("���� �����!");
	else
	{
		u1 = Convert::ToInt32(textBox1->Text);
		u2 = Convert::ToInt32(textBox2->Text);
		u3 = Convert::ToInt32(textBox3->Text);
		u4 = Convert::ToInt32(textBox4->Text);
		len = Convert::ToInt32(textBox5->Text);
		std::vector<unsigned long long> seq;
		if (len <= 0)
			MessageBox::Show("����� ������� �� ����� ���� ������������� ��� ������ ����!");
		else if (Convert::ToInt32(textBox1->Text) <= 1 || Convert::ToInt32(textBox2->Text) <= 7 || Convert::ToInt32(textBox3->Text) <= 15 || Convert::ToInt32(textBox4->Text) <= 127)
		{
			MessageBox::Show("�������� ��� ��������� ��������� �������!");
			textBox1->Clear();
			textBox2->Clear();
			textBox3->Clear();
			textBox4->Clear();
			textBox5->Clear();
			textBox6->Clear();
		}
		else
		{
			//������ � ����
			unsigned long long a, b, c, d;
			a = u1;
			b = u2;
			c = u3;
			d = u4;
			std::ofstream out("LFSR113_" + std::to_string(a) + "_" + std::to_string(b) + "_" + std::to_string(c) + "_" + std::to_string(d) + ".txt");
			out << "u1: " << u1 << "\nu2: " << u2 << "\nu3: " << u3 << "\nu4: " << u4 << "\n";
			for (int i = 0; i < len; i++)
			{
				el = lfsr113_ansi_generate_(u1, u2, u3, u4);
				out << el << "\n";
			}
			MessageBox::Show("������������������ ���������!");
		}
	}
}
private: System::Void �����������������ToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	unsigned long long u1, u2, u3, u4, el;
	int len;
	unsigned long long a, b, c, d;
	if (textBox1->Text == "" || textBox2->Text == "" || textBox3->Text == "" || textBox4->Text == "" || textBox5->Text == "") MessageBox::Show("���� �����!");
	else
	{
		u1 = Convert::ToInt32(textBox1->Text);
		u2 = Convert::ToInt32(textBox2->Text);
		u3 = Convert::ToInt32(textBox3->Text);
		u4 = Convert::ToInt32(textBox4->Text);
		len = Convert::ToInt32(textBox5->Text);
		a = u1;
		b = u2;
		c = u3;
		d = u4;
		std::vector<unsigned long long> seq;
		if (len <= 0)
			MessageBox::Show("����� ������� �� ����� ���� ������������� ��� ������ ����!");
		else if (Convert::ToInt32(textBox1->Text) <= 1 || Convert::ToInt32(textBox2->Text) <= 7 || Convert::ToInt32(textBox3->Text) <= 15 || Convert::ToInt32(textBox4->Text) <= 127)
		{
			MessageBox::Show("�������� ��� ��������� ��������� �������!");
			textBox1->Clear();
			textBox2->Clear();
			textBox3->Clear();
			textBox4->Clear();
			textBox5->Clear();
			textBox6->Clear();
		}
		else
		{
			for (int i = 0; i < len; i++)
			{
				el = lfsr113_ansi_generate_(u1, u2, u3, u4);
				seq.push_back(el);
			}

			int count = 0;
			std::ofstream out("reportLFSR113_" + std::to_string(a) + "_" + std::to_string(b) + "_" + std::to_string(c) + "_" + std::to_string(d) + ".txt");
			out << "u1: " << a << "\nu2: " << b << "\nu3: " << c << "\nu4: " << d << "\n" << "������� ������������� ���������:\n";
			std::vector<long long> repeat;
			bool m_flag = false;
			for (int i = 0; i < seq.size(); i++)
			{
				int flag = 0;
				if (repeat.size() == 0)
					for (int j = i; j < seq.size(); j++)
					{
						if (i != j && seq[i] == seq[j] && count == 0)
						{
							if (!m_flag) MessageBox::Show("��������� ���������� ���������!\n��������� � ����� reportLFSR113.txt");
							m_flag = true;
							count++;
							repeat.push_back(seq[i]);
							out << seq[i] << ": " << i << " " << j << " ";
						}
						else if (i != j && seq[i] == seq[j])
						{
							out << j << " ";
						}
					}
				else
				{
					for (int k = 0; k < repeat.size(); k++)
					{
						if (seq[i] == repeat[k]) flag = 1;
					}
					if (flag == 0)
						for (int j = i; j < seq.size(); j++)
						{
							if (i != j && seq[i] == seq[j] && count == 0)
							{
								if (!m_flag) MessageBox::Show("��������� ���������� ���������!\n��������� � ����� reportLFSR113.txt");
								count++;
								repeat.push_back(seq[i]);
								out << seq[i] << ": " << i << " " << j << " ";
							}
							else if (i != j && seq[i] == seq[j])
							{
								out << j << " ";
							}
						}
				}
				if (count != 0) out << "\n";
				count = 0;
			}

			if (!m_flag)
			{
				MessageBox::Show("������������� ��������� �� ����������!");
				out << "������������� ��������� �� ����������!";
			}
		}
	}
}
};
}
