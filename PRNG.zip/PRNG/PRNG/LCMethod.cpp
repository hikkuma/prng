#include "LCMethod.h"

long long lcm(long long m, long long a, long long c, long long seed)
{
	long long Z_i;
	Z_i = (a * seed + c) % m;
	return Z_i;
}