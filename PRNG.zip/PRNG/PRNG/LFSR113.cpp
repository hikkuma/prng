#include "LFSR113.h"
//unsigned u1 = 987654321, u2 = 987654321, u3 = 987654321, u4 = 987654321;

unsigned long long lfsr113_ansi_generate_(unsigned long long&u1, unsigned long long&u2, unsigned long long&u3, unsigned long long&u4) {
	unsigned long b;
	b = ((u1 << 6) ^ u1) >> 13;
	u1 = ((u1 & 4294967294U) << 18) ^ b;
	b = ((u2 << 2) ^ u2) >> 27;
	u2 = ((u2 & 4294967288U) << 2) ^ b;
	b = ((u3 << 13) ^ u3) >> 21;
	u3 = ((u3 & 4294967280U) << 7) ^ b;
	b = ((u4 << 3) ^ u4) >> 12;
	u4 = ((u4 & 4294967168U) << 13) ^ b;
	return (u1 ^ u2 ^ u3 ^ u4);
}


//unsigned lfsr113_consts512[64] __attribute__((aligned(64)))
//= { 4294967294U,4294967288U,4294967280U,4294967168U,
//4294967294U,4294967288U,4294967280U,4294967168U,
//4294967294U,4294967288U,4294967280U,4294967168U,
//4294967294U,4294967288U,4294967280U,4294967168U, 6,2,13,3,
//6,2,13,3, 6,2,13,3, 6,2,13,3, 13,27,21,12, 13,27,21,12,
//13,27,21,12, 13,27,21,12, 18,2,7,13, 18,2,7,13, 18,2,7,13,
//18,2,7,13 };
//unsigned ind[16] __attribute__((aligned(64))) =
//{ 0,4,8,12,0,4,8,12,0,4,8,12,0,4,8,12 };
//
//void lfsr113_avx512_generate_four_(lfsr113_state* state,
//	unsigned int* ans) {
//	asm volatile(
//		"vmovaps (%0),%%zmm1\n"\
//		"vmovaps (%1),%%zmm5\n"\
//		"vpandd %%zmm1, %%zmm5, %%zmm2\n"\
//		"vpsllvd 192(%1),%%zmm2,%%zmm2\n"\
//		"vpsllvd 64(%1),%%zmm1,%%zmm4\n"\
//		"vpxord %%zmm4,%%zmm1,%%zmm4\n"\
//		"vpsrlvd 128(%1),%%zmm4,%%zmm4\n"\
//		"vpxord %%zmm4,%%zmm2,%%zmm1\n"\
//		"vmovaps %%zmm1,(%0)\n"\
//		"vpshufd $78,%%zmm1,%%zmm2\n"\
//		"vpxord %%zmm2,%%zmm1,%%zmm3\n"\
//		"vpshufd $255,%%zmm3,%%zmm2\n"\
//		"vpxord %%zmm2,%%zmm3,%%zmm3\n"\
//		"vmovaps (%3),%%zmm4\n"\
//		"vpermd %%zmm3, %%zmm4, %%zmm3\n"\
//		"vmovaps %%xmm3, (%2)\n"\
//		"": :
//		"r"(state->u), "r"(lfsr113_consts512), "r"(ans), "r"(ind));
//}
