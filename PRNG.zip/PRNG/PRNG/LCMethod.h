#pragma once
long long lcm(long long m, long long a, long long c, long long seed);