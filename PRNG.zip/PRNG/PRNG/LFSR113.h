#pragma once
#ifndef LFSR_H_INCLUDED
#define LFSR_H_INCLUDED
unsigned long long lfsr113_ansi_generate_(unsigned long long& u1, unsigned long long& u2, unsigned long long& u3, unsigned long long& u4);

//typedef struct {
//	unsigned u[16]	 __attribute__((aligned(64)));
//} lfsr113_state;
//
//void lfsr113_avx512_generate_four_(lfsr113_state* state,
//	unsigned int* ans);

#endif // LFSR_H_INCLUDED